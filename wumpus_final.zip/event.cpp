#include "event.h"

#include <iostream>
#include <string>
#include <vector>

using namespace std;

/*I have not used this fucntion*/
Event::Event(char debug_character) {
    
}